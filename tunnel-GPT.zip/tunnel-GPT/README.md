docker build -t gpt .
docker run -d -p 18080:8080 --name gpt gpt

localhost:18080
