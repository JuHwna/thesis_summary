import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from lanarky import LangchainRouter

import chain

load_dotenv()

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# 체인 생성
llm_chain = chain.makeChain(k=2)

@app.get("/ping")
async def pong():
    return "pong"

# index 페이지 생성
@app.get("/")
async def get(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# LangchainRouter 생성
langchain_router = LangchainRouter(
    langchain_url="/chat", langchain_object=llm_chain, streaming_mode=1
)

# 웹소켓에 붙이기
langchain_router.add_langchain_api_websocket_route("/ws", langchain_object=llm_chain)

# FastAPI에 라우터 추가
app.include_router(langchain_router)

if __name__ == "__main__":
    uvicorn.run("main:app", reload=True, host="0.0.0.0", port=8080)
