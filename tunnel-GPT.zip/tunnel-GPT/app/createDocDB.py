#############################################################################################
##  Project Name       : Tunnel IoT - create DB using ChromaDB
##  
##  File Name          : createDocDB.py
##  Revision           : 0.2
##  Date               : 2023.08.08
##  Author             : Dongwoo Lee
##  Company            : airdeep
#############################################################################################
##
##  Code Example       : $ python createDocDB.py
##
#############################################################################################

import os
import sys
import logging
import pymysql
from datetime import datetime
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.document_loaders import TextLoader
from langchain.document_loaders import DirectoryLoader

# logging.debug("debug log")
# logging.info("info log")
# logging.warn("warn log")
# logging.error("error log")
# logging.critical("critical log")

def createDir(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
    except OSError:
        print("Error: Failed to create the directory.")
        
today = datetime.today().strftime("%Y%m%d")
logPath = f'log/DB_create/DB_create_{today}.log'
logFormat = '%(asctime)s %(levelname)s:%(message)s'

createDir('log/DB_create')
root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO) # or whatever
handler = logging.FileHandler(logPath, 'a', 'utf-8') # or whatever
formatter = logging.Formatter(logFormat) # or whatever
handler.setFormatter(formatter) # Pass handler as a parameter, not assign
root_logger.addHandler(handler)

############################## 고정 코드 시작 ##############################

apiKey = "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"
os.environ["OPENAI_API_KEY"] = apiKey

msg = ' Create DB Model '
logging.info(f'{msg:=^100}')

msg = f'Start Date : {today}'
logging.info(f'{msg:>100}')

msg = f'api key : {apiKey}'
logging.info(f'{msg:>100}')

msg = ''
logging.info(f'{msg:-^100}')

############################## 고정 코드 종료 ##############################

# file path
filePath = os.getcwd() ## base data dir path

# Load Embedding
embedding = OpenAIEmbeddings()

def loadDB():
    vectordb = Chroma(persist_directory='./articleDB'
                      , embedding_function=embedding
                     )
    return vectordb
        
def loadDoc(chunk_size, chunk_overlap):

    createDir(filePath + '/articles')
    
    # load Documents
    loader = DirectoryLoader(filePath + '/articles', glob="*.txt", loader_cls=TextLoader)
    documents = loader.load()
    
    # text split
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    texts = text_splitter.split_documents(documents)
    return texts, len(documents)

def createDB():

    try:
        vectordb = loadDB()
        num_content = vectordb._collection.count()
        if num_content > 0:
            root_logger.setLevel(logging.INFO)
            logging.info(f'    * The number of contexts in the DB (past) : {num_content}')
            vectordb._collection.delete()
            logging.info(f'    To create a new contexts, the old contexts was deleted')
        else:
            pass
    except:
        pass
        
    root_logger.setLevel(logging.ERROR)
    vectordb = Chroma.from_documents(documents=texts
                                     , embedding=embedding
                                     , persist_directory='./articleDB'
                                    )
    vectordb.persist()
    
    root_logger.setLevel(logging.INFO)
    num_content = vectordb._collection.count()
    logging.info(f'    * The number of contexts in the DB (now) : {num_content}')

if __name__ == '__main__':

    try:
        msg = '1. Start Load Document'
        logging.info(f'{msg:<100}')
        
        root_logger.setLevel(logging.INFO)
        texts, text_len = loadDoc(chunk_size=5000, chunk_overlap=300)

        root_logger.setLevel(logging.INFO)
        msg = '    Complete Load Document'
        logging.info(f'{msg:<100}')
        
    except:
        msg = f'''Error in the process of splitting text. Please check the "loadDoc" function or refer to below message.'''
        logging.error(f'{msg:<100}')
        logging.error(f'error context: {e}')
        sys.exit()
    
    try:
        msg = '2. Start Create Database'
        logging.info(f'{msg:<100}')

        root_logger.setLevel(logging.ERROR)
        createDB()
        
        root_logger.setLevel(logging.INFO)
        msg = '    Complete Create DB'
        logging.info(f'{msg:<100}')
        
    except Exception as e:
        if str(e)[:26] == "Incorrect API key provided":
            msg = f'Invalid API key. Please check your API key.'
            logging.error(f'{msg:<100}')
            sys.exit()
        else:
            msg = f'''Error in the process of splitting text. Please check the "loadDoc" function or refer to below message.'''
            logging.error(f'{msg:<100}')
            logging.error(f'error context: {e}')
            sys.exit()

    msg = ' Complete create Doc DB '
    logging.info(f'{msg:-^100}')
    
    msg = ''
    logging.info(f'{msg:=^100}')













