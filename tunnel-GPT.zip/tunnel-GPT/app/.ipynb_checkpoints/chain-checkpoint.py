#############################################################################################
# Project Name       : Tunnel IoT - respone query using GPT model
##
# File Name          : main.py
# Revision           : 0.2
# Date               : 2023.08.08
# Author             : Dongwoo Lee
# Company            : airdeep
#############################################################################################
##
# Code Example       : $ python main.py UserID "계측결과 보고 과정에 대해서 알려줘"
##
#############################################################################################

import os
import sys
import logging
import pymysql
import configparser
from datetime import datetime

from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings
from langchain.chat_models import ChatOpenAI
from langchain.chains import RetrievalQAWithSourcesChain
from langchain.document_loaders import TextLoader
from langchain.document_loaders import DirectoryLoader
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.callbacks.base import BaseCallbackHandler
from langchain.chains.question_answering import load_qa_chain
from langchain.prompts import PromptTemplate

def makeChain(k):
    # Prompt 관련
    template = """
        아래는 건설 계측공사 기준 법령에 관련한 질문이다. 질문에 한국어로 답한다.
        문서에 없어서 알 수 없는 질문의 경우 계측와(과) 관련된 질문을 해주시면 감사하겠습니다.라고 답한다.

        무시 : {summaries}
        질문 : {question}
    """
    # summaries
    PROMPT = PromptTemplate(input_variables=['summaries', 'question'], template=template)
    # PROMPT = PromptTemplate(input_variables=['question'], template=template)
    chain_type_kwargs = {"prompt": PROMPT}

    # DB 관련(Chroma)
    vectordb = Chroma(
        persist_directory='./articleDB',
        embedding_function=OpenAIEmbeddings()
    )
    retriever = vectordb.as_retriever(search_kwargs={"k": k})

    # RetrievalQAWithSourcesChain 리턴
    return RetrievalQAWithSourcesChain.from_chain_type(
        llm=ChatOpenAI(
            model="gpt-3.5-turbo-16k",
            temperature=0.1,
            streaming=True,
        ),
        chain_type="stuff",
        retriever=retriever,
        verbose=True,
        chain_type_kwargs=chain_type_kwargs,
        return_source_documents=False
    )

